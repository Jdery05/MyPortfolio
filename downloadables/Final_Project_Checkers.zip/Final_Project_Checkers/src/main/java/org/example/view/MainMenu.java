package org.example.view;

import org.example.model.Player;

public class MainMenu {
    MyIO io = new MyIO();

    public int mainMenu(){
        return io.getUserInt("~Welcome to Checkers!~" +
                "\n 1) Start (player vs player game)" +
                "\n 2) Exit",true);
        //Initial menu for the game
    }

    public int returnRow(){
        String collumSelect = io.getUserString("What row do you want to select?(A-H): ", true);
        switch (collumSelect.toUpperCase()){
            case "A":
                return 0;
            case "B":
                return 1;
            case "C":
                return 2;
            case "D":
                return 3;
            case "E":
                return 4;
            case "F":
                return 5;
            case "G":
                return 6;
            case "H":
                return 7;

        }
        //Ensures that the row returns the proper value
        return -1;
    }

    public void winScreen(Player player){
        //Ends game and returns the winner
        if (player.getName().equalsIgnoreCase("R")){
            System.out.println("Red Wins!");
        } else if (player.getName().equalsIgnoreCase("B")) {
            System.out.println("Black Wins!");
        }
    }

    public boolean forfeit(){
        String response = io.getUserString("Do you forfeit (y/n)", true);
        if (response.equalsIgnoreCase("y")){
            return true;
        }
        return false;
    }
}
