package org.example;

import org.example.controller.GameRules;

public class Main {
    public static void main(String[] args) {
        new GameRules().startHere();
        //Program made by Justin Dery and Jack Driggs.
    }
}