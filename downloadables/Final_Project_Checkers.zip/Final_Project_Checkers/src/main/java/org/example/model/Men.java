package org.example.model;

public class Men extends Piece {
    public Men(int index, String playerType) {
        super(index, playerType);

    }

    @Override
    public int jumpingRules(GameBoard board, int currentRow, int currentColumn, int intendedRow, int intendedColumn) {
        //Check forward diagonals
        //Check if able to jump
        int canJump = -2;
        if (playerType.equalsIgnoreCase("b")) {
            try {
                //Checks the forward diagonals, only for black pieces
                if (currentRow + 1 == intendedRow && currentColumn + 1 == intendedColumn) {
                    return checkSquare(board, intendedRow, intendedColumn);
                } else if (currentRow + 1 == intendedRow && currentColumn - 1 == intendedColumn) {
                    return checkSquare(board, intendedRow, intendedColumn);
                }
            } catch (Exception e) {

            }
        } else if (playerType.equalsIgnoreCase("r")){
            try {
                //Checks the forward diagonals only for red pieces
                if (currentRow - 1 == intendedRow && currentColumn + 1 == intendedColumn) {
                    return checkSquare(board, intendedRow, intendedColumn);
                } else if (currentRow - 1 == intendedRow && currentColumn - 1 == intendedColumn) {
                    return checkSquare(board, intendedRow, intendedColumn);
                }
            } catch (Exception e) {
                //Try catch negates any errors to do with null references (there are a lot).
                //Nothing has to actually be done with them, however, because we don't care
            }
        }
        return canJump;
    }

    public int checkSquare(GameBoard board, int row, int column) {
        if (board.returnCoordinateValue(row, column).index == -1) {
            return -1;
        }
        if (playerType.equalsIgnoreCase("b")) {
            if (board.returnCoordinateValue(row, column).playerType.equalsIgnoreCase("r")) {
                return board.returnCoordinateValue(row, column).index;
            } else if (board.returnCoordinateValue(row, column).playerType.equalsIgnoreCase("b")) {
                return -2;
            }
        } else if (playerType.equalsIgnoreCase("r")) {
            if (board.returnCoordinateValue(row, column).playerType.equalsIgnoreCase("b")) {
                return board.returnCoordinateValue(row, column).index;
            } else if (board.returnCoordinateValue(row, column).playerType.equalsIgnoreCase("r")) {
                return -2;
            }
        }
        return -2;
    }

    //This class is (Without Testing)
}
