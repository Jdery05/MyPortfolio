package org.example.model;

import org.example.view.MyIO;

import java.util.ArrayList;

public abstract class Player {
    MyIO io = new MyIO();
    public ArrayList<Piece> playersPieces = new ArrayList<Piece>();
    protected String name = "";
    protected boolean turn = false;

    public Player(boolean turn) {
    }

    public void setPieces(String playerType){
        for (int currentPiece = 0; currentPiece < 12; currentPiece++) {
            playersPieces.add(new Men(currentPiece, playerType));
        }
        //All players need pieces, so this function auto sets the arrays for them.
    }





    public Piece kingSwitch(Piece normalPiece){
        for (int currentPiece = 0; currentPiece < playersPieces.size(); currentPiece++) {
            if (playersPieces.get(currentPiece) == normalPiece){
                playersPieces.remove(currentPiece);
                King kingPiece = new King(normalPiece.index, normalPiece.playerType.toUpperCase());
                playersPieces.add(kingPiece);

                return kingPiece;
            }
        }
        //When a king is acquired it has to be added to the array, and have the old piece removed
        return null;
    }



    public boolean isTurn() {
        return turn;
    }
    //Checks if its their turn

    public void setTurn(boolean turn) {
        this.turn = turn;
    }
    //Sets their turn

    public String getName() {
        return name;
    }
    //Returns name, but never really used

    public void setName(String name) {
        this.name = name;
    }
    //Sets name, also hardly used


    //This class is (without testing)
}
