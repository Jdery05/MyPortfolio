package org.example.model;

public class GameBoard {
    public final static int rows = 8;
    public final static int columns = 8;
    public final static int rowInitialize = 3;
    private Piece[][] board = new Piece[rows][columns];

    public void setUpBoard(Player p1, Player p2) {
        //row 1 initialize
        //row 2 initialize
        //row 3 initialize
        initializePieces(p1, false);
        //row 6
        //row 7
        //row 8
        initializePieces(p2, true);
        //Fill in null pieces
        initializeNullPieces();
        //Row 4
        //Row 5
        initializeEmptyPieces();
    }

    public void initializePieces(Player player, boolean isRed) {
        int currentPiece = 0;
        int startingRow = 0;
        //Determines the starting row based on if its red or black
        if (isRed)
            startingRow = 5;
        for (int currentRow = startingRow; currentRow < rowInitialize + startingRow; currentRow++) {
            for (int currentColumn = 0; currentColumn < columns; currentColumn++) {
                //Multi-layered Array entrance logic
                if (currentRow % 2 == 1 && currentColumn % 2 == 1) {
                    board[currentRow][currentColumn] = player.playersPieces.get(currentPiece++);
                    //If the row and column are odd, add a piece
                }
                if (currentRow % 2 == 0 && currentColumn % 2 == 0) {
                    board[currentRow][currentColumn] = player.playersPieces.get(currentPiece++);
                    //If the row and column are even, add a piece
                }
            }
        }
    }

    public void initializeEmptyPieces(){
        int startingRow = 3;
        for (int currentRow = startingRow; currentRow < 5; currentRow++) {
            for (int currentColumn = 0; currentColumn < columns; currentColumn++) {
                //Multi-layered Array entrance logic
                if (currentRow % 2 == 1 && currentColumn % 2 == 1) {
                    board[currentRow][currentColumn] = new Empty(-1);
                    //If the row and column are odd, add a piece
                }
                if (currentRow % 2 == 0 && currentColumn % 2 == 0) {
                    board[currentRow][currentColumn] = new Empty(-1);
                    //If the row and column are even, add a piece
                }
            }
        }
    }

    public void initializeNullPieces(){
        //Fill in all the white-space
        for (int currentRow = 0; currentRow < rows; currentRow++) {
            for (int currentColumn = 0; currentColumn < columns; currentColumn++) {
                //Multi-layered array logic
                if (currentRow % 2 == 0 && currentColumn % 2 == 1){
                    board[currentRow][currentColumn] = null;
                    //If row is even and column is odd, fill null
                } else if (currentRow % 2 == 1 && currentColumn % 2 == 0) {
                    board[currentRow][currentColumn] = null;
                    //If row is odd and column is even, fill null
                }
            }
        }
    }

    public Piece removePieceByCoordinate(int row, int column){
        //grabs a piece off the board
        Piece piece = board[row][column];
        board[row][column] = new Empty(-1);
        //Replaces the piece with a new white space
        return piece;
        //returns piece in case we have a need for it still
    }

    public void movePieceOnBoard(int row, int column, int intendedRow, int intendedColumn){
        Piece piece = board[row][column];
        //Grabs a piece to store temporarily off the board in memory
        board[row][column] = board[intendedRow][intendedColumn];
        //Moves the empty space from where it was, to the current piece
        board[intendedRow][intendedColumn] = piece;
        //Replaces old empty space with our piece from before
    }

    public void kingReplace(Piece piece, Piece kingPiece){
        for (int currentRow = 0; currentRow < rows; currentRow++) {
            for (int currentColumn = 0; currentColumn < columns; currentColumn++) {
                //Multi-layered array entrance logic
                if (piece == returnCoordinateValue(currentRow, currentColumn)){
                    //Replaces the old "men" piece with the new "king" piece
                    board[currentRow][currentColumn] = kingPiece;
                }
            }
        }
    }

    public Piece returnCoordinateValue(int row, int column){
        return board[row][column];
    }
    //Used a lot, this method is how we access our array without making it public
    //This class is (Tested).
}
