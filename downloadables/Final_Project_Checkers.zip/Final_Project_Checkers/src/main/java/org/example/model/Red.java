package org.example.model;

import org.example.controller.GameRules;

import java.util.ArrayList;

public class Red extends Player{

    public Red(boolean turn){
        super(turn);
        setTurn(turn);
        setPieces("r");
        setName("R");
        //defaults pieces to red, and sets turn to false
    }


    @Override
    public void setTurn(boolean turn) {
        super.setTurn(turn);
    }



    //This class is (Without Testing)
}
