package org.example.model;

public class King extends Piece {

    public King(int index, String playerType) {
        super(index, playerType);
    }

    @Override
    public int jumpingRules(GameBoard board, int currentRow, int currentColumn, int intendedRow, int intendedColumn) {
        int canJump = -2;
        //Same jumping rules as men piece except it removes the color restrictions.
        try {
            if (currentRow + 1 == intendedRow && currentColumn + 1 == intendedColumn) {
                return checkSquare(board, intendedRow, intendedColumn);
            } else if (currentRow + 1 == intendedRow && currentColumn - 1 == intendedColumn) {
                return checkSquare(board, intendedRow, intendedColumn);
            } else if (currentRow - 1 == intendedRow && currentColumn + 1 == intendedColumn) {
                return checkSquare(board, intendedRow, intendedColumn);
            } else if (currentRow - 1 == intendedRow && currentColumn - 1 == intendedColumn) {
                return checkSquare(board, intendedRow, intendedColumn);
            }
        }   catch (Exception e) {

        }
        return canJump;
    }
    @Override
    public int checkSquare(GameBoard board, int row, int column){
        //Checks the square the piece would be moving to
        if (board.returnCoordinateValue(row, column).index == -1) {
            return -1;
        }
        //If the square is empty, return -1
        if (playerType.equalsIgnoreCase("b")) {
            if (board.returnCoordinateValue(row, column).playerType.equalsIgnoreCase("r")) {
                return board.returnCoordinateValue(row, column).index;
                //If a black piece jumps a red, return the index of the red piece
            } else if (board.returnCoordinateValue(row, column).playerType.equalsIgnoreCase("b")) {
                return -2;
                //If a black piece jumps black return index of -2 (default to no jump)
            }
        } else if (playerType.equalsIgnoreCase("r")) {
            if (board.returnCoordinateValue(row, column).playerType.equalsIgnoreCase("b")) {
                return board.returnCoordinateValue(row, column).index;
                //Same as above, red piece on black, return index
            } else if (board.returnCoordinateValue(row, column).playerType.equalsIgnoreCase("r")) {
                return -2;
                //Same as above, red piece on red, return -2
            }
        }
        return -2;
        //defaults a -2 return in case of error
    }


    //This class is (Without Testing)
}
