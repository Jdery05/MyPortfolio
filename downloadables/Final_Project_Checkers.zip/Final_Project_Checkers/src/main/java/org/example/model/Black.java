package org.example.model;

import org.example.controller.GameRules;

public class Black extends Player{


    public Black(boolean turn){
        super(turn);
        setTurn(turn);
        setPieces("b");
        setName("B");
        //Takes in a boolean that tells you the players turn immediately
        //Creates an array of pieces that belong to that player only
        //Sets name to capital letter representing their color
    }

    @Override
    public void setTurn(boolean turn) {
        super.setTurn(turn);
    }



    //This class is (Without Testing).
}
