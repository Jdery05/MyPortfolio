package org.example.view;

import org.example.model.GameBoard;

public class DisplayBoard {
    MyIO io = new MyIO();

    String boardDisplay = "";
    public void boardDisplay(GameBoard board){
        String newBoard = "  ";
        //Starts the board string with 3 spaces allowing the numbers to line-up properly
        for (int currentColumn = 0; currentColumn < GameBoard.columns; currentColumn++) {
            newBoard += columnCheck(currentColumn) + " ";
        }
        //Creates the numbers for the column
        newBoard += "\n";
        for (int currentSpace = 0; currentSpace < 18; currentSpace++) {
            newBoard += "-";
        }
        //Generates board outline (to 18 because that's board length)
        newBoard += "\n";
        for (int currentRow = 0; currentRow < GameBoard.rows; currentRow++) {
            newBoard += rowCheck(currentRow);
            //Generates Row Letters
            if (currentRow % 2 == 0){
                newBoard += "|";
            }
            //Adds pipes only on Even columns at the beginning, this makes it uniform
            for (int currentColumn = 0; currentColumn < GameBoard.columns; currentColumn++) {
                if (board.returnCoordinateValue(currentRow, currentColumn) == null){
                    newBoard += "| |";
                    //If piece is null creates a new square
                } else {
                    newBoard += board.returnCoordinateValue(currentRow, currentColumn).toString();
                    //If piece is occupied, adds its toString
                }
            }
            if (currentRow % 2 == 1){
                newBoard += "|";
            }
            //Adds pipes at the end for odd rows, like before, keeps it uniform
            newBoard += "\n";
        }
        for (int currentSpace = 0; currentSpace < 18; currentSpace++) {
            newBoard += "-";
            //Ends off the board, enclosing in a nice square
        }
        newBoard += "\n r = Red Pieces, b = Black Pieces, w = White Space " +
                "\n Uppercase means King Piece";
        boardDisplay = newBoard;
        displayBoard();
        //Calls the display board function, kept private so these calculations will
        //always be called whenever the board is attempted to be displayed.
        //Currently, requires an input (enter) to continue, might be fixable later.
    }

    private void displayBoard(){
        System.out.println(boardDisplay);

    }

    public void soutLine(String prompt){
        System.out.println(prompt);
    }

    private String rowCheck(int currentRow){
        switch (currentRow){
            case 0:
                return "A";
            case 1:
                return "B";
            case 2:
                return "C";
            case 3:
                return "D";
            case 4:
                return "E";
            case 5:
                return "F";
            case 6:
                return "G";
            case 7:
                return "H";
        }
        //Switch statement in its own method, so the main one doesn't get too unruly
        //Will return the alphabetical values for each row, instead of the numerical equivalents
        return "";
    }

    private String columnCheck(int currentColumn){
        switch (currentColumn){
            case 0:
                return "1";
            case 1:
                return "2";
            case 2:
                return "3";
            case 3:
                return "4";
            case 4:
                return "5";
            case 5:
                return "6";
            case 6:
                return "7";
            case 7:
                return "8";
        }
        //Switch statement in its own method, so the main one doesn't get too unruly
        //Will return the proper values for the columns in base 1 instead of 0
        return "";
    }
}
