package org.example.controller;

import org.example.model.*;
import org.example.view.DisplayBoard;
import org.example.view.MainMenu;
import org.example.view.MyIO;

public class GameRules {
    protected boolean win = false;
    protected int columnSelect;
    protected int rowSelect;
    MyIO io = new MyIO();
    MainMenu menu = new MainMenu();
    Player p1 = new Black(true);
    Player p2 = new Red(false);
    GameBoard gBoard = new GameBoard();
    DisplayBoard dBoard = new DisplayBoard();

    /**
     * This class is the entirety of logic for the game Checkers
     * It is easy to get lost in the jungle of code here, so documentation
     * is thorough and easy to follow
     * All code in this project was written by me (Justin Dery) or
     * my partner (Jack Driggs).
     */

    public void startHere() {
        int selection = -1;
        while (selection != 2) {
            //Simple while loop that ensures only the proper values are entered on the main menu
            selection = menu.mainMenu();
            switch (selection) {
                case 1:
                    setupGameBoard();
                    //move to next method
                case 2:
                    //exit
            }
        }
    }


    public void setupGameBoard() {
        gBoard.setUpBoard(p1, p2);
        dBoard.boardDisplay(gBoard);
        playGame();
        //Give Black 12 pieces on game board
        //Give Red 12 pieces on game board
        //Take black turn

    }


    public void playGame() {
        while (!isWin()) {
            //boolean function that determines if gameEnd or not
            if (p1.isTurn()) {
                takeTurn(p1);
                //Turn checker, and turn initiator
            } else if (p2.isTurn()) {
                takeTurn(p2);
                //Turn checker, and turn initiator
            }
            dBoard.boardDisplay(gBoard);
            //Displays game board
            switchTurns();
            //Swaps turns after turn has been taken
        }
        if (p1.isTurn()) {
            menu.winScreen(p2);
        }
        if (p2.isTurn()){
            menu.winScreen(p1);
        }
    }


    public boolean isWin() {
        //TODO: make Win Logic so game can end
        boolean didWin = false;
        //Logic to win the game
        //Two checks
        //Check 1, does player array hold any pieces
        if (p1.isTurn()){
            if (p1.playersPieces.isEmpty()){
                didWin = true;
            }
        } if (p2.isTurn()){
            if(p2.playersPieces.isEmpty()){
                didWin = true;
            }
        } if (menu.forfeit()) {
            didWin = true;
        }
        //Check 2, can current player move
        return didWin;
    }


    public void switchTurns() {
        if (p1.isTurn()) {
            p1.setTurn(false);
            p2.setTurn(true);
            dBoard.soutLine("Red's turn!");
            //Simple function that switches each players turn when needed
        } else {
            p2.setTurn(false);
            p1.setTurn(true);
            dBoard.soutLine("Black's turn!");
        }
    }

    public void takeTurn(Player player) {
        boolean takeTurn = checkIfJump(player);
        kingCheck();
        checkIfJump(player);
        //CheckIfJump called multiple times allows for double jump.
        //While KingCheck allows for a jump to the back rank to create a king.
        while (takeTurn) {
            if (player.isTurn()) {
                rowSelect = menu.returnRow();
                columnSelect = io.getUserInt("What column do you want to select?(1-8): ", true, 1, 8) - 1;
                while (rowSelect == -1) {
                    dBoard.soutLine("Bad Row Input, Please Try Again");
                    rowSelect = menu.returnRow();
                }
                //Above this comment is logic that allows you to select your piece.
                //This has checks in place to ensure valid input
                int rowJump = 0;
                int columnJump = 0;
                for (int currentPiece = 0; currentPiece < player.playersPieces.size(); currentPiece++) {
                    //We enter a for loop to begin searching for the proper piece to move, based on the info provided above
                    if (player.playersPieces.get(currentPiece) == gBoard.returnCoordinateValue(rowSelect, columnSelect)) {
                        //Turn logic
                        Piece piece = player.playersPieces.get(currentPiece);
                        rowJump = menu.returnRow();
                        columnJump = io.getUserInt("What column do you want to select(1-8): ", true, 1, 8) - 1;
                        while (rowSelect == -1) {
                            dBoard.soutLine("Bad Row Input, Please Try Again");
                            rowSelect = menu.returnRow();
                        }
                        //All logic above this finds the coordinated to move the piece too
                        takeTurn = takeMove(rowSelect, columnSelect, rowJump, columnJump, gBoard);
                        //Calls the takeMove function, which moves the pieces (no jumps are performed at this stage)
                        kingCheck();
                        //Checks if a king was made by that move
                        currentPiece = player.playersPieces.size() + 1;
                        //Exits the for loop by making the conditional false
                    }
                }
            }
        }
    }

    public boolean checkIfJump(Player player){
        int row;
        int column;
        for (int currentPiece = 0; currentPiece < player.playersPieces.size(); currentPiece++) {
            row = returnRow(player.playersPieces.get(currentPiece));
            column = returnColumn(player.playersPieces.get(currentPiece));
            //Not very dry code, but we don't talk about that, I wanted to be a little lazy
                try {
                    if (player.playersPieces.get(currentPiece).jumpingRules(gBoard, row, column, row + 1, column + 1) >= 0) {
                        if(takeJump(row, column, row + 2, column + 2, row + 1, column + 1)){
                            //Logic inside each if statement is the same, so I will put all documentation here
                            //takeJump returns a boolean to determine if the jump could be taken
                            //If the jump happens we return false, ending the players turn.
                            //If the jump fails (a piece blocked the jump path) it moves to the next if-statement.
                            return false;
                        }
                    } if (player.playersPieces.get(currentPiece).jumpingRules(gBoard, row, column, row + 1, column - 1) >= 0) {
                        if(takeJump(row, column, row + 2, column - 2, row + 1, column - 1)) {
                            return false;
                        }
                    } if (player.playersPieces.get(currentPiece).jumpingRules(gBoard, row, column, row - 1, column + 1) >= 0) {
                        if (takeJump(row, column, row - 2, column + 2, row - 1, column + 1)){
                            return false;
                        }
                    } if (player.playersPieces.get(currentPiece).jumpingRules(gBoard, row, column, row - 1, column - 1) >= 0) {
                        if(takeJump(row, column, row - 2, column - 2, row - 1, column - 1)) {
                            return false;
                        }
                    }
                    //Four separate checks that determine whether the piece can jump or not
                } catch (Exception e) {
                    //Like before, we need the system to ignore the multitude of null reference errors
                }
        }
        return true;
    }
    
    public int returnColumn(Piece piece){
        for (int currentRow = 0; currentRow < gBoard.rows; currentRow++) {
            for (int currentColumn = 0; currentColumn < gBoard.columns; currentColumn++) {
                if (piece.equals(gBoard.returnCoordinateValue(currentRow, currentColumn))){
                    return currentColumn;
                    //This function simply returns the column of a specific piece
                }
            }
        }
        return 0;
    }
    
    public int returnRow(Piece piece){
        for (int currentRow = 0; currentRow < gBoard.rows; currentRow++) {
            for (int currentColumn = 0; currentColumn < gBoard.columns; currentColumn++) {
                if (piece.equals(gBoard.returnCoordinateValue(currentRow, currentColumn))){
                    return currentRow;
                    //This function simply returns the row of a specific piece
                }
            }
        }
        return 0;
    }

    private boolean takeMove(int row, int column, int intendedRow, int intendedColumn, GameBoard board){
        boolean moveNotTaken = true;
        Piece piece = board.returnCoordinateValue(row, column);
        //Grabs a piece and holds it to use later
        if(piece.jumpingRules(board, row, column, intendedRow, intendedColumn) == -1) {
            //Checks if the pieces rules allow for a move, this is redundancy in case of -2 or >= 0
            board.movePieceOnBoard(row, column, intendedRow, intendedColumn);
            moveNotTaken = false;
        }
        return moveNotTaken;
        //Notice the boolean has inverted logic. This is because I used a copious amount of booleans
        //And this was the easiest way to follow the logic
        //Coding conventions be damned!!
    }

    private boolean takeJump(int row, int column, int intendedRow, int intendedColumn, int rowJumped, int columnJumped){
        if (gBoard.returnCoordinateValue(intendedRow, intendedColumn).index == -1){
            //Jump the piece
            removePlayerPiece(rowJumped,columnJumped);
            gBoard.removePieceByCoordinate(rowJumped, columnJumped);
            gBoard.movePieceOnBoard(row, column, intendedRow, intendedColumn);
            dBoard.soutLine("Piece Auto Jumped!");
            return true;
            //This calls all the relevant information to jump a piece, including removing that piece from
            //The arrays it belongs in so that it practically doesn't exist anymore
        }
        return false;
    }

    private void removePlayerPiece(int row, int column){
        if(p1.isTurn()){
            p2.playersPieces.remove(gBoard.removePieceByCoordinate(row, column));
        }else if(p2.isTurn()){
            p1.playersPieces.remove(gBoard.removePieceByCoordinate(row, column));
        }
        //This does what we did above but for the array lists (yea, they're public, sue me).
    }

    public void kingCheck(){
        for (int currentColumn = 0; currentColumn < gBoard.columns; currentColumn++) {
            try {
                Piece piece = gBoard.returnCoordinateValue(0, currentColumn);
                if (piece.playerType.equals("r")) {
                    //replaces the king piece on gameboard, and in player array
                    Piece kingPiece = p2.kingSwitch(piece);
                    gBoard.kingReplace(piece, kingPiece);
                    dBoard.soutLine(piece.playerType + " King Created!");
                }
            }catch (Exception e){
                //We get null references while searching the player array, so we decided to ignore them
                //Again
                //Quite a trend we have going on here
            }
        }
        for (int currentColumn = 0; currentColumn < gBoard.columns; currentColumn++) {
            try {
                Piece piece = gBoard.returnCoordinateValue(7, currentColumn);
                if (piece.playerType.equals("b")) {
                    //Same as above but for p1 not p2
                    Piece kingPiece = p1.kingSwitch(piece);
                    gBoard.kingReplace(piece, kingPiece);
                }
            }catch (Exception e){

            }
        }
    }
    //This class is (Without Testing)
}