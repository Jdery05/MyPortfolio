package org.example.model;

public abstract class Piece {
    public int index = 0;

    public String playerType;

    public Piece(int index, String playerType){
        this.index = index;
        this.playerType = playerType;
        //All pieces need an index and a playerType
    }

    public abstract int jumpingRules(GameBoard board, int currentRow, int currentColumn, int intendedRow, int intendedColumn);
    //Abstract jumping rules
    public abstract int checkSquare(GameBoard board, int row, int column);
    //Abstract check square
    @Override
    public String toString() {
        return playerType;
    }
    //To string simply returns the playerType

    //This class is (Without Testing)
}
