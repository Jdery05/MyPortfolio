package org.example.model;

public class Empty extends Piece{
    public Empty(int index) {
        super(index, "w");
        //Creates an empty (white space) piece that allows movement on viable squares.
        //Index that is passed in is defaulted to -1
    }


    @Override
    public int jumpingRules(GameBoard board, int currentRow, int currentColumn, int intendedRow, int intendedColumn) {
        return -2;
        //Returns -2 always from jumping rules to ensure no movement of white pieces is ever possible
        //Logic defaults that if it returns -2 it just negates the move
    }
    @Override
    public int checkSquare(GameBoard board, int row, int column){
        return -2;
    }
}
